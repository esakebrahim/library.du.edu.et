<?php

declare(strict_types=1);

namespace RobThree\Auth\Providers\Time;

use RobThree\Auth\TwoFactorAuthException;

class TimeException extends TwoFactorAuthException
{
}
